# ADAA Public Replication Package v1.0

**Status: PUBLIC RELEASE / CLEAN-RUN VALIDATED.**

This package accompanies the public working paper *Diversify the Decisions, Not Just the Assets: Autonomous Dynamic Asset Allocation as a Practical Multi-Rule Framework*.

It preserves the research paths used by the frozen scripts and provides a rights-safe route to reproduce the structural, performance, robustness, drawdown, FX-appendix and Strategy-Zoo evidence.

## What is included

- frozen R and Python research code;
- public source metadata and input contracts;
- derived figure/table source data;
- the 11 active public-paper figures;
- nonprivate clean-run validation summaries;
- exhibit-to-source-data pointers;
- SHA-256 manifest and a strict public-package validator.

## What is deliberately not redistributed

- downloaded raw Yahoo Finance market data;
- locally retrieved FRED/Yahoo runtime objects;
- the private June 2023 university project report binary;
- proprietary research files;
- third-party article PDFs;
- credentials, local session files or private author notes.

The scripts retrieve the required public-market inputs locally. Redistribution rights for upstream market data are not assumed merely because the data are publicly accessible.

## Reproduction

1. Extract the ZIP to a new temporary location. The archive creates a top-level `05_ADAA` folder.
2. Enter that folder.
3. Run `python 00_VALIDATE_PUBLIC_PACKAGE_v1_0.py` before starting.
4. Follow `RUN_ORDER_v1.0.md` exactly. The workflow intentionally keeps structural selection gates performance-blind until the prescribed performance-opening stage.
5. A full run will create local raw/runtime inputs. **Do not republish those inputs.** If you need to re-zip the package after a completed run, execute `python 01_PURGE_LOCAL_RUNTIME_INPUTS_FOR_REDISTRIBUTION_v1_0.py --confirm` and then rerun the validator.

## Validation record

The release clean run and publication reconciliation are documented under:

`03_Data_and_Code/03_Validation/Release_Clean_Run/`

The package validates reproducibility of a retrospective research workflow. It is not a live track record, not historical preregistration, and not evidence that the current HAA/BAA/ADM/FAA/LAA implementation must remain optimal or effective indefinitely.
